// SPDX-License-Identifier: GPL-3.0-or-later
#define EMUSTORE_HOST_TEST
#include "../src/installer.cpp"
#include <cassert>
struct Mock {int listener;const char *folder;std::uint64_t size;const char *hash;};
static void *receive_payload(void *ptr){
 auto &m=*static_cast<Mock*>(ptr);int fd=accept(m.listener,nullptr,nullptr);assert(fd>=0);
 auto *ctx=EVP_MD_CTX_new();assert(ctx);assert(EVP_DigestInit_ex(ctx,EVP_sha256(),nullptr)==1);
 char buf[65536];std::uint64_t total=0;ssize_t n;
 while((n=recv(fd,buf,sizeof(buf),0))>0){total+=n;assert(EVP_DigestUpdate(ctx,buf,n)==1);}assert(n==0);close(fd);assert(total==m.size);
 unsigned char digest[32];unsigned len;char hex[65];assert(EVP_DigestFinal_ex(ctx,digest,&len)==1);EVP_MD_CTX_free(ctx);
 for(unsigned i=0;i<32;++i)snprintf(hex+i*2,3,"%02x",digest[i]);assert(!strcmp(hex,m.hash));
 assert(directory(m.folder));for(auto *f:{"eboot.bin","sce_sys/param.json","sce_module/libc.prx"}) {char path[1024];snprintf(path,sizeof(path),"%s/%s",m.folder,f);assert(parents(path));FILE *o=fopen(path,"wb");assert(o);fputs("mock",o);fclose(o);}return nullptr;
}
int main(int argc,char **argv){assert(argc==3);assert(directory(argv[1]));
 for(unsigned i=0;i<catalog_count;++i){const auto &e=catalog[i];if(e.kind!=InstallKind::installer_elf)continue;
  int sock=socket(AF_INET,SOCK_STREAM,0);assert(sock>=0);int reuse=1;setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(reuse));
  sockaddr_in a{};a.sin_family=AF_INET;a.sin_port=htons(9021);a.sin_addr.s_addr=htonl(0x7f000001u);assert(bind(sock,reinterpret_cast<sockaddr*>(&a),sizeof(a))==0);assert(listen(sock,1)==0);
  char dest[1024],file[1024];snprintf(dest,sizeof(dest),"%s/%s",argv[1],e.title);snprintf(file,sizeof(file),"%s/%s",argv[2],strrchr(e.url,'/')+1);
  Mock m{sock,dest,e.size,e.sha256};pthread_t thread;assert(pthread_create(&thread,nullptr,receive_payload,&m)==0);
  assert(send_installer(file,dest));pthread_join(thread,nullptr);close(sock);assert(!send_installer(file,dest));assert(remove_tree(dest));
  assert(!send_installer(file,dest));printf("PASS %s: exact ELF transfer, existing destination refusal, loader absent\n",e.name);
 }assert(remove_tree(argv[1]));
}
