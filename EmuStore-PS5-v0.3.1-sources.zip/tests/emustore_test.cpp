// SPDX-License-Identifier: GPL-3.0-or-later
#define EMUSTORE_HOST_TEST
#include "../src/installer.cpp"
#include <cassert>
int main(int argc,char **argv) {
 assert(argc==5);root=argv[1];assert(directory(root));
 assert(!safe_path("../escape"));assert(!safe_path("PPSA97510/../../escape"));assert(!safe_path("/absolute"));assert(!safe_path("a\\b"));assert(!safe_path("a//b"));
 assert(mapped("PSXS5-v1.2.0/PPSA97510/eboot.bin",catalog[0]));assert(!mapped("PPSA00000/eboot.bin",catalog[0]));
 assert(!mapped("PCSX2/flags/jitdirect",catalog[0]));assert(mapped("release/PCSX2/flags/jitdirect",catalog[1]));
 for(unsigned i=0;i<3;++i){char stage[1024];snprintf(stage,sizeof(stage),"%s/extract-%u",root,i);assert(directory(stage));assert(extract(argv[i+2],stage,catalog[i]));printf("Archive %s verified and extracted\n",catalog[i].name);assert(remove_tree(stage));}
 char final[1024],home[1024];snprintf(home,sizeof(home),"%s/homebrew",root);assert(directory(home));snprintf(final,sizeof(final),"%s/homebrew/PPSA97510",root);assert(directory(final));assert(!install(catalog[0]));assert(exists(final));
 char sym[1024];snprintf(sym,sizeof(sym),"%s/symlink",root);assert(symlink("/tmp",sym)==0);assert(!directory(sym));assert(remove_tree(sym));
 char bad[1024],stage[1024];snprintf(stage,sizeof(stage),"%s/bad",root);assert(directory(stage));snprintf(bad,sizeof(bad),"%s/bad.zip",root);
 mz_zip_archive z{};assert(mz_zip_writer_init_file(&z,bad,0));assert(mz_zip_writer_add_mem(&z,"../escape","bad",3,0));assert(mz_zip_writer_finalize_archive(&z));assert(mz_zip_writer_end(&z));assert(!extract(bad,stage,catalog[0]));
 printf("Traversal, mapping, symlink and existing-install refusal tests passed\n");
 assert(remove_tree(root));return 0;
}
