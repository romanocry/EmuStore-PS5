// SPDX-License-Identifier: GPL-3.0-or-later
#define EMUSTORE_HOST_TEST
#include "../src/compat.cpp"
#include <cassert>
int main(){
 const char *dir="/tmp/emustore-compat-check";assert(own_directory(dir));
 assert(prove_write(dir));assert(prove_write(dir));
 std::uint64_t bytes=0;assert(compat_free_bytes(dir,bytes));assert(bytes>0);
 assert(!compat_free_bytes("/path/that/does/not/exist",bytes));assert(bytes==0);
 const char *link="/tmp/emustore-compat-link";assert(symlink(dir,link)==0);assert(!own_directory(link));unlink(link);
 assert(!prove_write("/path/that/does/not/exist"));assert(rmdir(dir)==0);
 puts("PASS data read/write proof, cleanup, symlink refusal, free-space detection and failure");
}
