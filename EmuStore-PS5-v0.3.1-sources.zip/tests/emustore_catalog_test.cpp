// SPDX-License-Identifier: GPL-3.0-or-later
#define EMUSTORE_HOST_TEST
#include "../src/installer.cpp"
#include <cassert>
int main(int argc,char **argv) {
 assert(argc==3);assert(catalog_count==15);root=argv[1];assert(directory(root));
 for(unsigned i=0;i<catalog_count;++i){const auto &e=catalog[i];
  if(e.kind==InstallKind::installer_elf)continue;
  char stage[1024],zip[1024];snprintf(stage,sizeof(stage),"%s/extract-%u",root,i);assert(directory(stage));
  snprintf(zip,sizeof(zip),"%s/%s",argv[2],strrchr(e.url,'/')+1);
  assert(extract(zip,stage,e));printf("PASS %s (%u entries max)\n",e.name,e.max_entries);fflush(stdout);
  assert(remove_tree(stage));
 }
 assert(!safe_path("../escape"));assert(!safe_path("/absolute"));assert(!safe_path("a\\b"));
 char home[1024],target[1024];snprintf(home,sizeof(home),"%s/homebrew",root);assert(directory(home));
 for(unsigned i=0;i<catalog_count;++i){snprintf(target,sizeof(target),"%s/homebrew/%s",root,catalog[i].title);assert(directory(target));assert(!install(catalog[i]));assert(exists(target));}
 puts("PASS all 15 existing-install refusals (including ELF installers)");
 assert(remove_tree(root));return 0;
}
