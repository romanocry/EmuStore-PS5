# Publication sur GitHub

Nom de dépôt proposé : `EmuStore-PS5`.
Description : « Store homebrew PS5 à la manette, projet porté par RomainJ. »

Publier le contenu de `sources/` à la racine du dépôt. Conserver LICENSE,
THIRD_PARTY_NOTICES.md, CREDITS.md et les licences dans assets/licenses/.
La licence du code est GPL-3.0-or-later ; les dépendances conservent leurs licences.
Le dossier compilé PPSA97631 peut être distribué comme archive dans une Release,
avec le code source correspondant et ses instructions de compilation.

Présenter cette version comme un prototype non testé sur console : la plage
4.xx–13.60 est un objectif, pas une compatibilité validée. Aucun jeu, BIOS ou
clé n'est inclus. Les émulateurs sont téléchargés depuis les liens officiels
fixes présents dans catalog.json.
