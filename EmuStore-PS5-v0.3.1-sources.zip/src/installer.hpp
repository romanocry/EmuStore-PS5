// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "catalog.hpp"
#include <atomic>
extern std::atomic<int> install_progress;
extern std::atomic<bool> install_busy;
void install_message(char *out, unsigned capacity);
bool start_install(unsigned index);
