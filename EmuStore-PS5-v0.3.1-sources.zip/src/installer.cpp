// SPDX-License-Identifier: GPL-3.0-or-later
#include "installer.hpp"
#include "compat.hpp"
#include "miniz/miniz.h"
#ifndef EMUSTORE_HOST_TEST
#include "console_curl.h"
#endif
#include <curl/curl.h>
#include <openssl/evp.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <cstdint>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <poll.h>
#include <time.h>
#include <initializer_list>

std::atomic<int> install_progress{0};
std::atomic<bool> install_busy{false};
static pthread_mutex_t msg_lock = PTHREAD_MUTEX_INITIALIZER;
static char message[128] = "CHOISIS UN EMULATEUR PUIS APPUIE SUR CROIX";
static const char *root = "/data";
static void say(const char *s) {
 compat_log(s);
 pthread_mutex_lock(&msg_lock); snprintf(message,sizeof(message),"%s",s); pthread_mutex_unlock(&msg_lock);
}
void install_message(char *out, unsigned capacity) {
 pthread_mutex_lock(&msg_lock); snprintf(out,capacity,"%s",message); pthread_mutex_unlock(&msg_lock);
}
static bool exists(const char *p) {struct stat s{}; return lstat(p,&s)==0;}
static bool directory(const char *p) {
 if(mkdir(p,0777)==0) return true;
 struct stat s{}; return errno==EEXIST && lstat(p,&s)==0 && S_ISDIR(s.st_mode);
}
static bool regular(const char *p) {struct stat s{}; return lstat(p,&s)==0 && S_ISREG(s.st_mode) && s.st_size>0;}
// Private staging trees only; never follow symlinks.
static bool remove_tree(const char *p) {
 struct stat s{}; if(lstat(p,&s)!=0) return errno==ENOENT;
 if(!S_ISDIR(s.st_mode)) return unlink(p)==0;
 DIR *d=opendir(p); if(!d)return false; bool ok=true;
 while(auto *e=readdir(d)) { if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;
  char path[2048]; if(snprintf(path,sizeof(path),"%s/%s",p,e->d_name)>=int(sizeof(path)) || !remove_tree(path))ok=false;
 } closedir(d); return rmdir(p)==0 && ok;
}
static bool safe_path(const char *p) {
 if(!*p || *p=='/' || strlen(p)>900)return false;
 const char *part=p;
 for(const char *c=p;;++c) {
  if(*c=='\\'||*c==':'||(*c && (unsigned char)*c<32))return false;
  if(*c=='/'||!*c) {size_t n=size_t(c-part);
   if(n==0 && *c)return false;
   if((n==1 && *part=='.')||(n==2 && part[0]=='.' && part[1]=='.'))return false;
   part=c+1;
  }
  if(!*c)break;
 } return true;
}
// Accept the expected title or PCSX2 data at archive root or below one release wrapper.
static const char *mapped(const char *p,const Entry &e) {
 if(!safe_path(p))return nullptr;
 for(int depth=0;depth<2;++depth) {
  size_t n=strlen(e.title);
  if(!strncmp(p,e.title,n) && p[n]=='/')return p;
  if(e.ps2 && !strncmp(p,"PCSX2/",6))return p;
  const char *slash=strchr(p,'/');if(!slash)break;p=slash+1;
 } return nullptr;
}
static bool parents(char *p) {
 for(char *c=p+1;*c;++c)if(*c=='/') {*c=0;bool ok=directory(p);*c='/';if(!ok)return false;}return true;
}
struct Sink {FILE *f;std::uint64_t bytes,limit;EVP_MD_CTX *hash;};
static size_t write_download(char *p,size_t size,size_t count,void *v) {
 auto &s=*static_cast<Sink*>(v);size_t n=size*count;
 if(n>s.limit-s.bytes)return 0;
 size_t w=fwrite(p,1,n,s.f);if(w!=n || EVP_DigestUpdate(s.hash,p,n)!=1)return 0;
 s.bytes+=n;install_progress.store(int(s.bytes*70/s.limit));return n;
}
static bool download(const char *url,const char *path,std::uint64_t size,const char *hash) {
 int fd=open(path,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0600);if(fd<0)return false;
 FILE *f=fdopen(fd,"wb");if(!f){close(fd);return false;}
 EVP_MD_CTX *ctx=EVP_MD_CTX_new();if(!ctx){fclose(f);return false;}
 if(EVP_DigestInit_ex(ctx,EVP_sha256(),nullptr)!=1){EVP_MD_CTX_free(ctx);fclose(f);return false;}
 Sink sink{f,0,size,ctx};CURL *c=curl_easy_init();if(!c){EVP_MD_CTX_free(ctx);fclose(f);return false;}
#ifndef EMUSTORE_HOST_TEST
 console_curl_setup(c);
#endif
 curl_easy_setopt(c,CURLOPT_URL,url);curl_easy_setopt(c,CURLOPT_USERAGENT,"EmuStore-PS5/0.1");
 curl_easy_setopt(c,CURLOPT_PROTOCOLS_STR,"https");curl_easy_setopt(c,CURLOPT_REDIR_PROTOCOLS_STR,"https");
 curl_easy_setopt(c,CURLOPT_SSL_VERIFYPEER,1L);curl_easy_setopt(c,CURLOPT_SSL_VERIFYHOST,2L);
 curl_easy_setopt(c,CURLOPT_NOSIGNAL,1L);curl_easy_setopt(c,CURLOPT_FOLLOWLOCATION,1L);
 curl_easy_setopt(c,CURLOPT_MAXREDIRS,8L);curl_easy_setopt(c,CURLOPT_FAILONERROR,1L);
 curl_easy_setopt(c,CURLOPT_CONNECTTIMEOUT,20L);curl_easy_setopt(c,CURLOPT_TIMEOUT,1200L);
 curl_easy_setopt(c,CURLOPT_LOW_SPEED_LIMIT,1024L);curl_easy_setopt(c,CURLOPT_LOW_SPEED_TIME,60L);
 curl_easy_setopt(c,CURLOPT_HTTP_VERSION,CURL_HTTP_VERSION_1_1);curl_easy_setopt(c,CURLOPT_BUFFERSIZE,262144L);
 curl_easy_setopt(c,CURLOPT_WRITEFUNCTION,write_download);curl_easy_setopt(c,CURLOPT_WRITEDATA,&sink);
 CURLM *multi=curl_multi_init();bool ok=false;
 if(multi && curl_multi_add_handle(multi,c)==CURLM_OK) {
  int running=1;CURLMcode mc=CURLM_OK;
  while(running && mc==CURLM_OK) {
   auto before=sink.bytes;mc=curl_multi_perform(multi,&running);
   if(running && mc==CURLM_OK && before==sink.bytes){int ready=0;mc=curl_multi_poll(multi,nullptr,0,10,&ready);}
  }
  int left=0;CURLMsg *m;while((m=curl_multi_info_read(multi,&left)))if(m->msg==CURLMSG_DONE){ok=m->data.result==CURLE_OK; if(!ok){char error[160];snprintf(error,sizeof(error),"HTTPS curl=%d %s",int(m->data.result),curl_easy_strerror(m->data.result));compat_log(error);}}
  long status=0;curl_easy_getinfo(c,CURLINFO_RESPONSE_CODE,&status);ok=ok && mc==CURLM_OK && status==200;
  curl_multi_remove_handle(multi,c);
 }
 if(multi)curl_multi_cleanup(multi);curl_easy_cleanup(c);
 unsigned char digest[32];unsigned len=0;char hex[65]{};
 ok=ok && sink.bytes==size;
 if(EVP_DigestFinal_ex(ctx,digest,&len)!=1 || len!=32)ok=false;
 else {for(unsigned i=0;i<32;++i)snprintf(hex+i*2,3,"%02x",digest[i]);if(strcmp(hex,hash))ok=false;}
 EVP_MD_CTX_free(ctx);if(fflush(f)!=0 || fsync(fileno(f))!=0)ok=false;if(fclose(f)!=0)ok=false;return ok;
}
static size_t extract_write(void *v,mz_uint64 offset,const void *p,size_t n) {
 auto *f=static_cast<FILE*>(v);if(offset!=static_cast<mz_uint64>(ftello(f)))return 0;return fwrite(p,1,n,f);
}
static bool extract(const char *zip,const char *stage,const Entry &e) {
 mz_zip_archive z{};if(!mz_zip_reader_init_file(&z,zip,0))return false;
 auto count=mz_zip_reader_get_num_files(&z);bool ok=count>0 && count<=e.max_entries;std::uint64_t total=0;
 // Validate every entry before writing, including ignored paths.
 for(mz_uint i=0;ok && i<count;++i) {
  mz_zip_archive_file_stat s{};ok=mz_zip_reader_file_stat(&z,i,&s)!=0;if(!ok)break;
  unsigned type=(s.m_external_attr>>16)&0170000;
  if(mz_zip_reader_get_filename(&z,i,nullptr,0)>sizeof(s.m_filename) || !safe_path(s.m_filename)||(type && type!=0100000 && type!=0040000)||s.m_is_encrypted||!s.m_is_supported) {ok=false;break;}
  total+=s.m_uncomp_size;if(total>e.unpacked_limit || s.m_uncomp_size>512ULL*1024*1024)ok=false;
 }
 for(mz_uint i=0;ok && i<count;++i) {
  mz_zip_archive_file_stat s{};mz_zip_reader_file_stat(&z,i,&s);
  const char *relative=mapped(s.m_filename,e);if(!relative)continue;
  char target[2048];if(snprintf(target,sizeof(target),"%s/%s",stage,relative)>=int(sizeof(target))){ok=false;break;}
  if(s.m_is_directory) {size_t n=strlen(target);if(n && target[n-1]=='/')target[n-1]=0;ok=parents(target)&&directory(target);continue;}
  if(!parents(target)){ok=false;break;}
  int fd=open(target,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0777);if(fd<0){ok=false;break;}
  FILE *f=fdopen(fd,"wb");if(!f){close(fd);ok=false;break;}
  ok=mz_zip_reader_extract_to_callback(&z,i,extract_write,f,0)!=0;
  if(fflush(f)!=0 || fsync(fileno(f))!=0)ok=false;if(fclose(f)!=0)ok=false;
  install_progress.store(70+int(i*25/count));
 }
 mz_zip_reader_end(&z);if(!ok)return false;
 char path[2048];
 if(e.kind==InstallKind::launcher_zip){
  snprintf(path,sizeof(path),"%s/%s/%s",stage,e.title,e.primary);if(!regular(path))return false;
  snprintf(path,sizeof(path),"%s/%s/homebrew.js",stage,e.title);return regular(path);
 }
 const char *required[]={"eboot.bin","sce_sys/param.json","sce_module/libc.prx"};
 for(auto *name:required){snprintf(path,sizeof(path),"%s/%s/%s",stage,e.title,name);if(!regular(path))return false;}
 return true;
}
static std::uint64_t monotonic_ms() {
 struct timespec ts{};clock_gettime(CLOCK_MONOTONIC,&ts);
 return std::uint64_t(ts.tv_sec)*1000+ts.tv_nsec/1000000;
}
static bool native_ready(const char *folder) {
 char p[1024];for(auto *name:{"eboot.bin","sce_sys/param.json","sce_module/libc.prx"}) {
  snprintf(p,sizeof(p),"%s/%s",folder,name);if(!regular(p))return false;
 } return true;
}
// Official installer payloads are sent only to the console's own pre-existing ELF loader.
static bool send_installer(const char *path,const char *final) {
 if(exists(final)){say("DEJA PRESENT - INSTALLATEUR NON LANCE");return false;}
 FILE *f=fopen(path,"rb");if(!f){say("LECTURE INSTALLATEUR IMPOSSIBLE");return false;}
 unsigned char magic[5]{};bool ok=fread(magic,1,5,f)==5 && !memcmp(magic,"\177ELF\2",5);rewind(f);
 if(!ok){fclose(f);say("FORMAT INSTALLATEUR INVALIDE");return false;}
 int sock=socket(AF_INET,SOCK_STREAM,0);if(sock<0){fclose(f);say("SOCKET IMPOSSIBLE");return false;}
#ifdef EMUSTORE_HOST_TEST
 ok=fcntl(sock,F_SETFL,O_NONBLOCK)==0;
#else
 ok=console_curl_nonblocking(sock)==0;
#endif
 struct sockaddr_in addr{};addr.sin_family=AF_INET;addr.sin_port=htons(9021);addr.sin_addr.s_addr=htonl(0x7f000001u);
#ifndef EMUSTORE_HOST_TEST
 addr.sin_len=sizeof(addr);
#endif
 if(ok && connect(sock,reinterpret_cast<sockaddr*>(&addr),sizeof(addr))<0 && errno!=EINPROGRESS)ok=false;
 struct pollfd pd{sock,POLLOUT,0};int err=0;socklen_t len=sizeof(err);
 if(ok)ok=poll(&pd,1,5000)>0 && getsockopt(sock,SOL_SOCKET,SO_ERROR,&err,&len)==0 && err==0;
 if(!ok){close(sock);fclose(f);say("ACTIVER LE CHARGEUR ELF LOCAL SUR LE PORT 9021");return false;}
 say("ENVOI DE L INSTALLATEUR OFFICIEL");
 char buf[65536];std::size_t n;auto deadline=monotonic_ms()+120000;
 while(ok && (n=fread(buf,1,sizeof(buf),f))>0) {
  std::size_t off=0;
  while(ok && off<n) {
   if(monotonic_ms()>deadline){ok=false;break;}
   int ready=poll(&pd,1,1000);if(ready<0 && errno==EINTR)continue;
   if(ready<0 || (ready>0 && (pd.revents&(POLLERR|POLLHUP|POLLNVAL)))){ok=false;break;}
   if(ready==0)continue;
   auto wrote=send(sock,buf+off,n-off,MSG_NOSIGNAL);
   if(wrote<0 && (errno==EINTR || errno==EAGAIN || errno==EWOULDBLOCK))continue;
   if(wrote<=0){ok=false;break;}off+=std::size_t(wrote);
  }
 }
 if(ferror(f))ok=false;fclose(f);shutdown(sock,SHUT_WR);close(sock);
 if(!ok){say("ENVOI INTERROMPU - VERIFIER LA CONSOLE AVANT REESSAI");return false;}
 say("INSTALLATEUR ENVOYE - ATTENTE DES FICHIERS");deadline=monotonic_ms()+60000;
 while(monotonic_ms()<deadline){if(native_ready(final)){install_progress.store(100);say("FICHIERS PRESENTS - VERIFIER LA NOTIFICATION PS5");return true;}usleep(250000);}
 say("ENVOYE - INSTALLATION NON CONFIRMEE SUR LA CONSOLE");return false;
}
static bool install(const Entry &e) {
 char homebrew[512],store[512],final[512],data[512],stage[256],zip[512],staged[512],stageddata[512];
 snprintf(homebrew,sizeof(homebrew),"%s/homebrew",root);snprintf(store,sizeof(store),"%s/emustore",root);
 snprintf(final,sizeof(final),"%s/homebrew/%s",root,e.title);snprintf(data,sizeof(data),"%s/PCSX2",root);
 if(!directory(homebrew)||!directory(store)){say("ACCES DATA REFUSE - VERIFIER SHADOWMOUNTPLUS");return false;}
 if(exists(final)||(e.ps2 && exists(data))){say("DEJA PRESENT - AUCUN FICHIER MODIFIE");return false;}
 std::uint64_t available=0;
 if(!compat_free_bytes(store,available)){say("ESPACE NON MESURABLE - VOIR RAPPORT COMPATIBILITE");return false;}
 if(available<e.size+e.unpacked_limit+256ULL*1024*1024){say("ESPACE INSUFFISANT - VOIR TAILLE DANS LA NOTICE");return false;}
 bool created=false;
 for(unsigned i=0;i<100;++i){snprintf(stage,sizeof(stage),"%s/emustore/stage-%u-%u",root,unsigned(getpid()),i);if(mkdir(stage,0700)==0){created=true;break;}if(errno!=EEXIST)break;}
 if(!created){say("IMPOSSIBLE DE CREER LE DOSSIER TEMPORAIRE");return false;}
 snprintf(zip,sizeof(zip),"%s/archive.zip",stage);say("TELECHARGEMENT ET VERIFICATION SHA256");
 bool ok=download(e.url,zip,e.size,e.sha256);
 if(!ok)say("ECHEC RESEAU OU VERIFICATION - REESSAYER");
 if(ok && e.kind==InstallKind::installer_elf) {
  bool sent=send_installer(zip,final); remove_tree(stage); return sent;
 }
 if(ok){say("EXTRACTION ET CONTROLE DES FICHIERS");ok=extract(zip,stage,e);if(!ok)say("ARCHIVE INVALIDE OU ERREUR ECRITURE");}
 char helper[512]{},finalhelper[512]{};
 if(ok && e.helper_url[0]) {
  snprintf(helper,sizeof(helper),"%s/%s",stage,e.helper_name);
  snprintf(finalhelper,sizeof(finalhelper),"%s/emustore/%s",root,e.helper_name);
  if(exists(finalhelper)){say("HELPER DEJA PRESENT - INSTALLATION ANNULEE");ok=false;}
  else {say("TELECHARGEMENT DU HELPER");ok=download(e.helper_url,helper,e.helper_size,e.helper_hash);if(!ok)say("ECHEC TELECHARGEMENT HELPER");}
 }
 snprintf(staged,sizeof(staged),"%s/%s",stage,e.title);snprintf(stageddata,sizeof(stageddata),"%s/PCSX2",stage);
 bool moveddata=false,movedhelper=false;
 if(ok && e.ps2){struct stat st{};ok=lstat(stageddata,&st)==0 && S_ISDIR(st.st_mode);if(!ok)say("DONNEES PS2 ABSENTES DE L ARCHIVE");}
 if(ok && (exists(final)||(e.ps2 && exists(data))||(e.helper_url[0] && exists(finalhelper)))) {say("DESTINATION DEJA PRESENTE - ANNULE");ok=false;}
 if(ok && e.ps2){ok=rename(stageddata,data)==0;moveddata=ok;if(!ok)say("ECHEC COPIE DONNEES PS2");}
 if(ok && e.helper_url[0]){ok=rename(helper,finalhelper)==0;movedhelper=ok;if(!ok)say("ECHEC COPIE HELPER");}
 if(ok) {ok=rename(staged,final)==0; if(!ok)say("ECHEC COPIE FINALE - INSTALLATION ANNULEE");}
 if(!ok){if(movedhelper)rename(finalhelper,helper);if(moveddata)rename(data,stageddata);}
 remove_tree(stage);
 if(ok){install_progress.store(100);say(e.helper_url[0]?"INSTALLE - HELPER ET PREREQUIS DANS LA NOTICE":e.kind==InstallKind::launcher_zip?"INSTALLE - OUVRIR DANS HOMEBREW LAUNCHER":"INSTALLE - RELANCER SHADOWMOUNTPLUS SI NECESSAIRE");}
 return ok;
}
static void *worker(void *arg){
 if(curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK)say("INITIALISATION RESEAU IMPOSSIBLE");
 else install(catalog[reinterpret_cast<std::uintptr_t>(arg)]);
 install_busy.store(false);return nullptr;
}
bool start_install(unsigned index){
 if(index>=catalog_count || install_busy.exchange(true))return false;
 install_progress.store(0);pthread_t t{};
 if(pthread_create(&t,nullptr,worker,reinterpret_cast<void*>(std::uintptr_t(index)))!=0){say("IMPOSSIBLE DE LANCER LE TELECHARGEMENT");install_busy.store(false);return false;}
 pthread_detach(t);return true;
}
