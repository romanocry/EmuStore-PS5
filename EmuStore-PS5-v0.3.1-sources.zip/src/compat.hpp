// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <cstdint>
void compat_init();
void compat_log(const char *message);
const char *compat_system();
const char *compat_data_status();
// Detection is informative only: an SDK version can be spoofed by the environment.
bool compat_free_bytes(const char *path, std::uint64_t &bytes);
