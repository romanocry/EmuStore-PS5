// SPDX-License-Identifier: GPL-3.0-or-later
#include "compat.hpp"
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <pthread.h>
#ifndef EMUSTORE_HOST_TEST
#include <sys/types.h>
#include <sys/sysctl.h>
#endif
static char system_text[80]="VERSION SYSTEME NON LUE";
static char data_text[80]="ACCES DATA NON TESTE";
static FILE *log_file=nullptr;
static pthread_mutex_t log_lock=PTHREAD_MUTEX_INITIALIZER;
void compat_log(const char *message){
 pthread_mutex_lock(&log_lock);
 if(log_file){fprintf(log_file,"%s\n",message);fflush(log_file);}
 pthread_mutex_unlock(&log_lock);
}
const char *compat_system(){return system_text;}
const char *compat_data_status(){return data_text;}
static bool own_directory(const char *path){
 if(mkdir(path,0777)==0)return true;
 struct stat st{};return errno==EEXIST && lstat(path,&st)==0 && S_ISDIR(st.st_mode);
}
static bool prove_write(const char *directory){
 char path[256];int fd=-1;
 for(unsigned i=0;i<16;++i){snprintf(path,sizeof(path),"%s/probe-%u-%u",directory,unsigned(getpid()),i);
  fd=open(path,O_RDWR|O_CREAT|O_EXCL|O_NOFOLLOW,0600);if(fd>=0)break;if(errno!=EEXIST)return false;
 }
 if(fd<0)return false;
 constexpr char token[]="EMUSTORE-COMPAT-0.3";char back[sizeof(token)]{};
 bool ok=write(fd,token,sizeof(token))==sizeof(token) && fsync(fd)==0 && lseek(fd,0,SEEK_SET)==0 && read(fd,back,sizeof(back))==sizeof(back) && memcmp(back,token,sizeof(token))==0;
 if(close(fd)!=0)ok=false;if(unlink(path)!=0)ok=false;return ok;
}
bool compat_free_bytes(const char *path,std::uint64_t &bytes){
 struct statvfs v{};
 if(statvfs(path,&v)==0 && (v.f_frsize || v.f_bsize)){
  bytes=std::uint64_t(v.f_bavail)*(v.f_frsize?v.f_frsize:v.f_bsize);return true;
 }
 int fd=open(path,O_RDONLY|O_DIRECTORY|O_NOFOLLOW);
 if(fd>=0){
  struct statvfs fallback{};int result=fstatvfs(fd,&fallback);close(fd);
  if(result==0 && (fallback.f_frsize || fallback.f_bsize)){
   bytes=std::uint64_t(fallback.f_bavail)*(fallback.f_frsize?fallback.f_frsize:fallback.f_bsize);return true;
  }
 }

 bytes=0;return false;
}
void compat_init(){
#ifndef EMUSTORE_HOST_TEST
 std::uint32_t sdk=0;std::size_t size=sizeof(sdk);
 if(sysctlbyname("kern.sdk_version",&sdk,&size,nullptr,0)==0 && size==sizeof(sdk))
  snprintf(system_text,sizeof(system_text),"SDK ANNONCE %X.%02X - VALEUR INDICATIVE",sdk>>24,(sdk>>16)&255);
#endif
 const bool data_ok=own_directory("/data/emustore") && prove_write("/data/emustore");
 snprintf(data_text,sizeof(data_text),"%s",data_ok?"DATA : LECTURE ET ECRITURE OK":"DATA : ECRITURE REFUSEE - VERIFIER LE LOADER");
 const char *log_path=data_ok?"/data/emustore/compatibility.log":"/download0/emustore-compatibility.log";
 // Do not truncate or follow a pre-existing symlink. Each launch appends its result.
 int fd=open(log_path,O_WRONLY|O_CREAT|O_APPEND|O_NOFOLLOW,0600);
 if(fd>=0){log_file=fdopen(fd,"a");if(!log_file)close(fd);}
 compat_log("=== EmuStore 0.3 - target 4.xx to 13.60; hardware validation pending ===");
 compat_log(system_text);compat_log(data_text);
 std::uint64_t free=0;char line[100];if(compat_free_bytes("/data",free))snprintf(line,sizeof(line),"DATA free bytes: %llu",static_cast<unsigned long long>(free));else snprintf(line,sizeof(line),"DATA free space unavailable; installation will refuse until measurable");compat_log(line);
}
