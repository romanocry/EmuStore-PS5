// EmuStore PS5 - SPDX-License-Identifier: GPL-3.0-or-later
// Uses BlackBearReloaded's GPL-3.0-or-later native renderer and controller sample.
#include "demo_renderer.hpp"
#include "installer.hpp"
#include "compat.hpp"
#include <array>
#include <cstdio>
#include <cstdint>
#include <sys/stat.h>
using ps5::demo::Canvas;
using ps5::demo::Color;
struct PadSample {std::uint32_t buttons;std::uint8_t sticks[6],reserved0[66];std::int32_t connected;std::uint64_t timestamp;std::uint8_t reserved1[32];};
static_assert(sizeof(PadSample)==120);
extern "C" {
 int sceUserServiceInitialize(const void*);
 int sceUserServiceGetInitialUser(int*);
 int scePadInit(void);
 int scePadOpen(int,int,int,const void*);
 int scePadRead(int,PadSample*,int);
 int sceSystemServiceLoadExec(const char*,const char**);
}
static int selected=0,pad=-1;
static std::uint32_t held=0;
static bool confirm=false,show_compat=false;
static void label(Canvas &c,unsigned x,unsigned y,const char *s,unsigned scale,Color col) {
 char upper[128];unsigned i=0;for(;s[i] && i<127;++i)upper[i]=(s[i]>='a' && s[i]<='z')?char(s[i]-32):s[i];upper[i]=0;c.text(x,y,upper,scale,col);
}
static void frame(Canvas &c) noexcept {
 std::array<PadSample,16> samples{};std::uint32_t down=0;
 if(pad>=0){int n=scePadRead(pad,samples.data(),16);for(int i=0;i<n && i<16;++i){if(!samples[i].connected){held=0;continue;}down|=samples[i].buttons & ~held;held=samples[i].buttons;}}
 bool busy=install_busy.load();
 if(!busy){
  if(down&0x8000){show_compat=!show_compat;confirm=false;}
  if(show_compat && (down&0x2000)){show_compat=false;down=0;}
  if(down&0x2000){if(confirm)confirm=false;else sceSystemServiceLoadExec("exit",nullptr);}
  if(!confirm && !show_compat){
   int step=0;if(down&0x80)step=-1;if(down&0x20)step=1;
   if(down&0x10)step=-3;if(down&0x40)step=3;
   if(down&0x400)step=-6;if(down&0x800)step=6;
   selected=(selected+step+int(catalog_count))%int(catalog_count);
  }
  if((down&0x4000) && !show_compat){if(confirm){start_install(unsigned(selected));confirm=false;}else confirm=true;}
 }
 c.clear(Color::background);
 if(show_compat){
  c.text(105,90,"COMPATIBILITE",9,Color::white);
  c.text(105,220,"CIBLE 4.XX A 13.60 - NON VALIDEE SUR CONSOLE",4,Color::yellow);
  label(c,105,330,compat_system(),3,Color::white);
  label(c,105,400,compat_data_status(),3,Color::white);
  c.text(105,510,"HTTPS : CERTIFICATS INCLUS ET VERIFICATION ACTIVE",3,Color::cyan);
  c.text(105,590,"LES EMULATEURS ONT LEURS PROPRES PREREQUIS",3,Color::white);
  c.text(105,710,"RAPPORT : DATA / EMUSTORE / COMPATIBILITY.LOG",3,Color::white);
  c.text(105,770,"SINON : DOWNLOAD0 / EMUSTORE-COMPATIBILITY.LOG",3,Color::white);
  c.text(105,950,"CARRE OU ROND : RETOUR",4,Color::cyan);return;
 }

 c.text(100,60,"EMUSTORE",10,Color::white);
 c.text(105,155,"PS5   /   INSTALLATION SIMPLE   /   V0.3.1",3,Color::cyan);
 c.text(1420,155,"PAR ROMAINJ.",3,Color::cyan);
 char page[64];snprintf(page,sizeof(page),"PAGE %d / %u",selected/6+1,(catalog_count+5)/6);
 label(c,1420,100,page,4,Color::white);
 c.rectangle(105,210,1710,4,Color::cyan);
 const int first=(selected/6)*6;
 for(int slot=0;slot<6;++slot){int i=first+slot;if(i>=int(catalog_count))break;
  unsigned x=105+unsigned(slot%3)*580,y=250+unsigned(slot/3)*240;
  c.rectangle(x,y,550,215,i==selected?Color::cyan:Color::panel);
  c.rectangle(x+4,y+4,542,207,Color::panel);
  label(c,x+22,y+24,catalog[i].name,3,Color::white);
  label(c,x+22,y+80,catalog[i].system,2,Color::cyan);
  label(c,x+22,y+114,catalog[i].version,2,Color::white);
  char path[160];snprintf(path,sizeof(path),"/data/homebrew/%s",catalog[i].title);struct stat st{};
  label(c,x+22,y+163,stat(path,&st)==0?"DEJA PRESENT":"INSTALLER",3,i==selected?Color::yellow:Color::white);
 }
 label(c,105,742,catalog[selected].note,3,Color::yellow);
 if(confirm){
  c.text(105,792,catalog[selected].kind==InstallKind::installer_elf?"LANCER L INSTALLATEUR OFFICIEL ?":"INSTALLER CETTE APPLICATION ?",3,Color::white);
  c.text(105,835,"CROIX CONFIRMER   /   ROND ANNULER",3,Color::white);
 } else {char msg[128];install_message(msg,sizeof(msg));label(c,105,812,msg,3,Color::white);}
 if(busy){c.rectangle(105,877,1710,18,Color::panel);c.rectangle(105,877,unsigned(install_progress.load())*1710/100,18,Color::cyan);}
 c.text(105,936,"DIRECTION CHOISIR   L1 R1 PAGE   CROIX INSTALLER",3,Color::white);
 c.text(105,985,pad<0?"MANETTE NON DETECTEE - FERMER ET RELANCER":"ROND QUITTER   /   CARRE COMPATIBILITE",3,pad<0?Color::yellow:Color::cyan);

}
int main(){compat_init();int user=0;sceUserServiceInitialize(nullptr);if(sceUserServiceGetInitialUser(&user)==0 && scePadInit()>=0)pad=scePadOpen(user,0,0,nullptr);ps5::demo::run_frames(frame,"EMUSTORE READY");}
